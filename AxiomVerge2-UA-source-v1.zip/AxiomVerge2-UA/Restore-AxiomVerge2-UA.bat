@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Restore-AxiomVerge2-UA.ps1"
if errorlevel 1 (
  echo.
  echo Restore did not complete. Read the message above.
  pause
)
endlocal
