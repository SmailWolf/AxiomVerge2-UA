#!/usr/bin/env python3
"""Build, install, or restore the AV2 Ukrainian patch using the user's own game files."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys

BASE = Path(__file__).resolve().parent
VERSION = json.loads((BASE / 'supported-version.json').read_text(encoding='utf-8'))
ORIGINALS = VERSION['files']
BACKUP_NAME = 'UA-localization-backup'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def fail(message):
    raise SystemExit(message)


def paths(game):
    return {name: game / Path(name) for name in ORIGINALS}


def verify_hashes(items, expected, label):
    for name, value in expected.items():
        path = items[name]
        if not path.is_file() or digest(path) != value:
            fail(f'{label}: {name}')


def restore(game, backup, state):
    current = paths(game)
    saved = paths(backup)
    verify_hashes(current, state['patched_sha256'], 'Файл гри змінено після встановлення, відновлення зупинено')
    verify_hashes(saved, ORIGINALS, 'Резервну копію пошкоджено')
    for name in ORIGINALS:
        target = current[name]
        temp = target.with_name(target.name + '.ua-restore-tmp')
        shutil.copy2(saved[name], temp)
        os.replace(temp, target)
    (backup / 'state.json').unlink(missing_ok=True)
    print('Оригінальні файли гри відновлено. Резервну копію залишено.')


def install(game):
    exe = game / 'AxiomVerge2.exe'
    if not exe.is_file():
        fail('Вкажіть папку гри, де лежить AxiomVerge2.exe.')
    backup = game / BACKUP_NAME
    state_file = backup / 'state.json'
    if state_file.exists():
        state = json.loads(state_file.read_text(encoding='utf-8'))
        restore(game, backup, state)
    verify_hashes(paths(game), ORIGINALS, 'Ця копія гри не збігається з перевіреною версією')

    node = shutil.which('node')
    if not node:
        fail('Потрібен Node.js. Встановіть його й запустіть установлювач знову.')
    try:
        import PIL  # noqa: F401
    except ImportError:
        pip = [sys.executable, '-m', 'pip', 'install', '--user', '-r', str(BASE / 'requirements.txt')]
        result = subprocess.run(pip)
        if result.returncode:
            fail('Не вдалося встановити Pillow. Переконайтеся, що Python/pip та інтернет доступні.')

    child_env = os.environ.copy()
    child_env['PYTHON'] = sys.executable
    result = subprocess.run([node, str(BASE / 'src' / 'patcher.js'), str(game)], cwd=BASE, env=child_env)
    if result.returncode:
        fail('Не вдалося зібрати патч. Оригінальні файли гри не змінено.')
    built = game / 'build' / 'Axiom Verge 2 UA patch'
    built_files = {name: (built / name) for name in ORIGINALS}
    verify_built = {name: digest(path) for name, path in built_files.items() if path.is_file()}
    if len(verify_built) != len(ORIGINALS):
        fail('Збірка неповна: бракує EXE або одного зі шрифтів.')

    backup.mkdir(parents=True, exist_ok=True)
    saved = paths(backup)
    for name in ORIGINALS:
        if not saved[name].exists():
            saved[name].parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(game / name, saved[name])
    verify_hashes(saved, ORIGINALS, 'Резервна копія не відповідає оригінальній версії')
    state = {
        'installed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'patched_sha256': verify_built,
        'original_sha256': ORIGINALS,
    }
    state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    changed = []
    try:
        for name, source in built_files.items():
            target = game / name
            temp = target.with_name(target.name + '.ua-install-tmp')
            shutil.copy2(source, temp)
            os.replace(temp, target)
            changed.append(name)
    except BaseException:
        for name in changed:
            shutil.copy2(saved[name], game / name)
        state_file.unlink(missing_ok=True)
        raise
    print('Українську локалізацію Axiom Verge 2 встановлено.')
    print(f'Оригінали збережено тут: {backup}')
    print(f'Звіт збірки: {built / "build-report.json"}')


def main():
    args = sys.argv[1:]
    is_restore = '--restore' in args
    args = [x for x in args if x != '--restore']
    if len(args) != 1:
        fail('Використання: python install.py <папка-гри> [--restore]')
    game = Path(args[0]).expanduser().resolve()
    if not game.is_dir():
        fail('Папку гри не знайдено.')
    backup = game / BACKUP_NAME
    state_file = backup / 'state.json'
    if is_restore:
        if not state_file.is_file():
            fail('Стан встановлення не знайдено.')
        restore(game, backup, json.loads(state_file.read_text(encoding='utf-8')))
    else:
        install(game)


if __name__ == '__main__':
    main()
