$ErrorActionPreference = 'Stop'
try {
    if (!(Get-Command node.exe -ErrorAction SilentlyContinue)) { throw 'Спершу встановіть Node.js.' }
    if (!(Get-Command py.exe -ErrorAction SilentlyContinue)) { throw 'Спершу встановіть Python 3 з командою py.' }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Виберіть папку Axiom Verge 2 з файлом AxiomVerge2.exe'
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 1 }
    $answer = Read-Host "Зібрати й установити українізатор у $($dialog.SelectedPath)? (Y/N)"
    if ($answer -notin @('Y','y','YES','yes')) { Write-Host 'Встановлення скасовано.'; exit 1 }
    & py.exe -3 (Join-Path $PSScriptRoot 'install.py') $dialog.SelectedPath
    if ($LASTEXITCODE -ne 0) { throw 'Установлення не завершено.' }
    Read-Host 'Готово. Натисніть Enter, щоб закрити'
} catch {
    Write-Host "Помилка: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host 'Натисніть Enter, щоб закрити'
    exit 1
}
