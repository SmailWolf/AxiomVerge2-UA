#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
global.JSZip = require('./vendor/jszip.min.js');
require('./glyphs.js');
const V = require('./verge-core.js');
const EXPECTED_EXE_SHA256 = '942e46daaefb33ae9fe877aece24dfd25247d1c2a14be076e8285786e209d575';
const TRANSLATION_FILES = ['UI','Skills','Items','Hacks','Dialogue','Notes','NPCs','Messages'];
const CREDIT_TITLES = {
  'by':'Автор', 'Dedicated To':'Присвячується', 'Vocals by':'Вокал',
  'Business and Marketing':'Бізнес і маркетинг', 'Bookkeeping':'Бухгалтерія',
  'Trailers and Marketing Video':'Трейлери й рекламні відео', 'Localization':'Локалізація',
  'Built Using':'Створено за допомогою', 'Special Thanks':'Особлива подяка',
  'And of course...':'І, звісно...'
};
function ensure(ok, message) { if (!ok) throw new Error(message); }
function hash(b) { return crypto.createHash('sha256').update(b).digest('hex'); }
function countText(haystack, needle) { return haystack.split(needle).length - 1; }
function replaceSpeechCulture(input) {
  const out=Buffer.from(input),from=Buffer.from('en-US','utf16le'),to=Buffer.from('uk-UA','utf16le');
  const positions=[];
  for(let p=0;(p=out.indexOf(from,p))>=0;p+=from.length)positions.push(p);
  ensure(positions.length===1,'Не вдалося однозначно знайти системну мову озвучення у цій версії EXE.');
  to.copy(out,positions[0]);
  return new Uint8Array(out);
}
function pythonCommand() {
  if (process.env.PYTHON) return {exe:process.env.PYTHON, prefix:[]};
  return process.platform === 'win32' ? {exe:'py', prefix:['-3']} : {exe:'python3', prefix:[]};
}
async function main() {
  const gameRoot = path.resolve(process.argv[2] || '');
  const exePath = path.join(gameRoot, 'AxiomVerge2.exe');
  ensure(process.argv[2] && fs.existsSync(exePath), 'Вкажіть папку гри, де лежить AxiomVerge2.exe.');
  const original = new Uint8Array(fs.readFileSync(exePath));
  ensure(hash(original) === EXPECTED_EXE_SHA256,
    'Ця версія AxiomVerge2.exe не збігається з перевіреною. Файли гри не змінено.');
  const supported = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'supported-version.json'), 'utf8'));
  for (const [relative, expected] of Object.entries(supported.files)) {
    const sourcePath = path.join(gameRoot, relative);
    ensure(fs.existsSync(sourcePath) && hash(fs.readFileSync(sourcePath)) === expected,
      `Файл гри ${relative} не збігається з перевіреною версією.`);
  }
  const pe = V.peInfo(original);
  const resource = pe.resources.find(r => /Content\.zip$/i.test(r.name));
  ensure(resource, 'У EXE не знайдено вбудований архів Content.zip.');
  const content = await JSZip.loadAsync(resource.data, {checkCRC32:true});
  const expectedFiles = Object.keys(content.files).length;
  let translated = 0;
  const touched = [];
  for (const table of TRANSLATION_FILES) {
    const archivePath = `Text/${table}.csv`;
    ensure(content.file(archivePath), `В архіві гри немає ${archivePath}.`);
    const rows = V.parseCSV(await content.file(archivePath).async('string'));
    const keyColumn = rows[0].indexOf('Key');
    const englishColumn = rows[0].indexOf('English');
    ensure(keyColumn >= 0 && englishColumn >= 0, `У ${archivePath} немає колонок Key та English.`);
    const translations = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'translations', `${table}.json`), 'utf8'));
    const indices = new Map();
    for (let i=1;i<rows.length;i++) if (rows[i][keyColumn]) {
      const list=indices.get(rows[i][keyColumn])||[]; list.push(i); indices.set(rows[i][keyColumn],list);
    }
    for (const [key,value] of Object.entries(translations)) {
      const found=indices.get(key)||[];
      ensure(found.length===1, `Ключ ${key} у ${archivePath} має бути рівно один.`);
      ensure(typeof value==='string', `Переклад ${key} не є текстом.`);
      rows[found[0]][englishColumn]=value.replace(/\\n/g,'\n');
      translated++;
    }
    content.file(archivePath, V.csvString(rows), {createFolders:false});
    touched.push(archivePath);
  }
  let credits = await content.file('Text/Credits_English.xml').async('string');
  for (const [en,ua] of Object.entries(CREDIT_TITLES)) {
    const old=`mTitle="${en}"`;
    ensure(countText(credits,old)>0, `У титрах не знайдено заголовок ${en}.`);
    credits=credits.split(old).join(`mTitle="${ua}"`);
  }
  const you='<THCreditsEntry>YOU</THCreditsEntry>';
  ensure(credits.includes(you), 'У титрах не знайдено рядок YOU.');
  credits=credits.replace(you,'<THCreditsEntry>ВАМ</THCreditsEntry>');
  if (!credits.startsWith('\uFEFF')) credits='\uFEFF'+credits;
  content.file('Text/Credits_English.xml', Buffer.from(credits,'utf8'), {createFolders:false});
  touched.push('Text/Credits_English.xml');

  const archive = await content.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:9}});
  const check=await JSZip.loadAsync(archive,{checkCRC32:true});
  ensure(Object.keys(check.files).length===expectedFiles,'Під час складання змінилася структура архіву гри.');
  for (const name of Object.keys(content.files)) {
    if (touched.includes(name)) continue;
    const [before,after]=await Promise.all([content.file(name).async('uint8array'),check.file(name).async('uint8array')]);
    ensure(V.equal(before,after),`Несподівано змінився файл ${name}.`);
  }
  const rebuilt=V.replaceResource(original,resource.name,archive,2);
  ensure(rebuilt.changes.length===1,'Не вдалося зберегти адаптацію ширини колонок мов.');
  const patchedBytes=replaceSpeechCulture(rebuilt.bytes);
  const root=path.join(gameRoot,'build','Axiom Verge 2 UA patch');
  const outFonts=path.join(root,'Content','Fonts');
  fs.rmSync(root,{recursive:true,force:true});
  fs.mkdirSync(outFonts,{recursive:true});
  fs.writeFileSync(path.join(root,'AxiomVerge2.exe'),patchedBytes);
  const py=pythonCommand();
  const fontRun=spawnSync(py.exe,[...py.prefix,path.join(__dirname,'build_fonts.py'),path.join(gameRoot,'Content','Fonts'),outFonts,path.join(root,'font-report.json')],{encoding:'utf8'});
  if (fontRun.status!==0) throw new Error(fontRun.stderr||'Не вдалося створити українські шрифти. Переконайтеся, що Pillow встановлено.');
  const reportPath=path.join(root,'font-report.json');
  const fontReport=JSON.parse(fs.readFileSync(reportPath,'utf8'));
  const required=['AV8ptMonogame.xnb','Hooge0655_8pt.xnb','Moire16pt.xnb','Uni0553_6pt.xnb','Uni0553_8pt.xnb'];
  for (const name of required) ensure(fs.existsSync(path.join(outFonts,name)),`Не створено шрифт ${name}.`);
  fs.writeFileSync(path.join(root,'README-UA.txt'),
    'Українська локалізація для Axiom Verge 2. Замініть AxiomVerge2.exe та папку Content/Fonts файлами з цього пакета. Перед заміною створіть резервну копію.\\n');
  const summary={game:'Axiom Verge 2',originalExeSha256:hash(original),patchedExeSha256:hash(patchedBytes),translations:translated,translatedFiles:TRANSLATION_FILES,modifiedArchiveFiles:touched,archiveFiles:expectedFiles,exeChanges:[...rebuilt.changes,'uk-UA voice culture'],fonts:fontReport};
  fs.writeFileSync(path.join(root,'build-report.json'),JSON.stringify(summary,null,2));
  console.log(`Український патч зібрано: ${root}`);
  console.log(`Перекладено ${translated} записів; змінено ${touched.length} файлів тексту/титрів і зібрано ${fontReport.length} шрифтів.`);
}
main().catch(e=>{console.error('Помилка: '+e.message);process.exit(1);});
