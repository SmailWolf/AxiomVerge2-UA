/* Local binary and localization tools. Files are processed in this browser only. */
(function(global){
'use strict';
const utf8=new TextDecoder('utf-8',{fatal:true}),enc=new TextEncoder(),U32=0xffffffff;
const assert=(v,s)=>{if(!v)throw new Error(s);};
const align=(v,a)=>Math.ceil(v/a)*a;
const bytes=v=>v instanceof Uint8Array?v:new Uint8Array(v);
function concat(parts){let n=parts.reduce((s,b)=>s+b.length,0),b=new Uint8Array(n),p=0;for(const a of parts){b.set(a,p);p+=a.length;}return b;}
function peInfo(input){
 const b=bytes(input),v=new DataView(b.buffer,b.byteOffset,b.byteLength);assert(b.length>256&&v.getUint16(0,true)===0x5a4d,'Потрібен виконуваний файл Windows (.exe) гри.');
 const pe=v.getUint32(60,true);assert(pe+256<b.length&&v.getUint32(pe,true)===0x4550,'Непідтримуваний заголовок EXE.');
 const opt=pe+24,magic=v.getUint16(opt,true),dd=opt+(magic===0x10b?96:112);assert(magic===0x10b||magic===0x20b,'Непідтримувана архітектура EXE.');
 const count=v.getUint16(pe+6,true),sectionStart=opt+v.getUint16(pe+20,true),sections=[];
 for(let i=0;i<count;i++){const p=sectionStart+i*40;sections.push({p,name:new TextDecoder().decode(b.subarray(p,p+8)).replace(/\0/g,''),vs:v.getUint32(p+8,true),va:v.getUint32(p+12,true),size:v.getUint32(p+16,true),raw:v.getUint32(p+20,true)});}
 function offset(rva){for(const s of sections)if(rva>=s.va&&rva<s.va+Math.max(s.vs,s.size)){const x=s.raw+rva-s.va;assert(x<b.length,'Пошкоджена адреса в EXE.');return x;}throw new Error('Не вдалося знайти секцію EXE.');}
 const cli=offset(v.getUint32(dd+14*8,true));assert(v.getUint32(dd+14*8,true)>0,'Це не .NET-версія Axiom Verge.');
 const md=offset(v.getUint32(cli+8,true));assert(v.getUint32(md,true)===0x424a5342,'Пошкоджені метадані .NET.');
 let p=align(md+16+v.getUint32(md+12,true),4),streams={};const streamCount=v.getUint16(p+2,true);p+=4;
 for(let i=0;i<streamCount;i++){const o=v.getUint32(p,true),n=v.getUint32(p+4,true);p+=8;let e=p;while(b[e]!==0&&e<b.length)e++;const name=utf8.decode(b.subarray(p,e));streams[name]={p:md+o,size:n};p=align(e+1,4);}
 const ts=streams['#~']||streams['#-'];assert(ts&&streams['#Strings'],'Немає таблиць метаданих.');p=ts.p;const heaps=b[p+6],lo=v.getUint32(p+8,true),hi=v.getUint32(p+12,true),rows=Array(64).fill(0);p+=24;
 for(let i=0;i<64;i++)if(i<32?(lo>>>i)&1:(hi>>>(i-32))&1){rows[i]=v.getUint32(p,true);assert(rows[i]<2000000,'Надто велика таблиця .NET.');p+=4;}
 const codes={ResolutionScope:[2,[0,26,35,1]],TypeDefOrRef:[2,[2,1,27]],MemberRefParent:[3,[2,1,26,6,27]],HasConstant:[2,[4,8,23]],HasCustomAttribute:[5,[6,4,1,2,8,9,10,0,14,23,20,17,26,27,32,35,38,39,40,42,44,43]],CustomAttributeType:[3,[6,10]],HasFieldMarshal:[1,[4,8]],HasDeclSecurity:[2,[2,6,32]],HasSemantics:[1,[20,23]],MethodDefOrRef:[1,[6,10]],MemberForwarded:[1,[4,6]],Implementation:[2,[38,35,39]],TypeOrMethodDef:[1,[2,6]]};
 const schema=[['u2','s','g','g','g'],['ResolutionScope','s','s'],['u4','s','s','TypeDefOrRef',4,6],[4],['u2','s','b'],[6],['u4','u2','u2','s','b',8],[8],['u2','u2','s'],[2,'TypeDefOrRef'],['MemberRefParent','s','b'],['u2','HasConstant','b'],['HasCustomAttribute','CustomAttributeType','b'],['HasFieldMarshal','b'],['u2','HasDeclSecurity','b'],['u2','u4',2],['u4',4],['b'],[2,20],[20],['u2','s','TypeDefOrRef'],[2,23],[23],['u2','s','b'],['u2',6,'HasSemantics'],[2,'MethodDefOrRef','MethodDefOrRef'],['s'],['b'],['u2','MemberForwarded','s',26],['u4',4],['u4','u4'],['u4'],['u4','u2','u2','u2','u2','u4','b','s','s'],['u4'],['u4','u4','u4'],['u2','u2','u2','u2','u4','b','s','s','b'],['u4',35],['u4','u4','u4',35],['u4','s','b'],['u4','u4','s','s','Implementation'],['u4','u4','s','Implementation'],[2,2],['u2','u2','TypeOrMethodDef','s'],['MethodDefOrRef','b'],[42,'TypeDefOrRef']];
 function size(t){if(t==='u2')return 2;if(t==='u4')return 4;if(typeof t==='number')return rows[t]<65536?2:4;if(t==='s'||t==='g'||t==='b')return heaps&({s:1,g:2,b:4}[t])?4:2;const [bits,tables]=codes[t];return Math.max(...tables.map(x=>rows[x]))<(1<<(16-bits))?2:4;}
 const tables=[];for(let i=0;i<64;i++){if(!rows[i])continue;assert(schema[i],'Непідтримувана таблиця .NET '+i);const fields=schema[i].map(size),len=fields.reduce((a,b)=>a+b,0);tables[i]={p,len,fields};p+=rows[i]*len;assert(p<=ts.p+ts.size,'Пошкоджені таблиці .NET.');}
 function row(i,n){const t=tables[i];let o=t.p+(n-1)*t.len;return t.fields.map(w=>{const a=w===2?v.getUint16(o,true):v.getUint32(o,true);o+=w;return a;});}
 function str(n){let p=streams['#Strings'].p+n,e=p;while(b[e]&&e<b.length)e++;return utf8.decode(b.subarray(p,e));}
 const resourceStart=offset(v.getUint32(cli+24,true)),resourceSize=v.getUint32(cli+28,true),resources=[];
 for(let i=1;i<=rows[40];i++){const rr=row(40,i);if(rr[3]!==0)continue;const p=resourceStart+rr[0],length=v.getUint32(p,true);assert(p+4+length<=resourceStart+resourceSize,'Пошкоджений ресурс гри.');resources.push({name:str(rr[2]),offset:rr[0],tableOffset:tables[40].p+(i-1)*tables[40].len,data:b.slice(p+4,p+4+length)});}
 return {b,v,pe,opt,dd,cli,md,sections,offset,rows,tables,row,str,resourceStart,resourceSize,resources};
}
function body(info,rva){if(!rva)return null;const p=info.offset(rva),h=info.b[p];if((h&3)===2)return {p:p+1,length:h>>>2};assert((h&3)===3,'Непідтримуване тіло методу.');return {p:p+(info.v.getUint16(p,true)>>>12)*4,length:info.v.getUint32(p+4,true)};}
function patchFontRouting(info,b,game){
 const dv=new DataView(b.buffer),changes=[];
 if(game===2){for(let ti=1;ti<=info.rows[2];ti++){const t=info.row(2,ti);if(info.str(t[1])!=='THOptionsState')continue;const end=ti<info.rows[2]?info.row(2,ti+1)[5]:info.rows[6]+1;
 for(let mi=t[5];mi<end;mi++){const m=info.row(6,mi);if(info.str(m[3])!=='UpdateLayout')continue;const bd=body(info,m[0]);let ok=bd&&bd.length>0x1f8;
 for(const o of [0xd8,0x1f4])ok=ok&&b[bd.p+o]===0x22&&[8,16].includes(dv.getFloat32(bd.p+o+1,true));
 if(ok){for(const o of [0xd8,0x1f4])dv.setFloat32(bd.p+o+1,8,true);changes.push('AV2: проміжки мов 8 px');}
 }}
 } else {
  for(let ti=1;ti<=info.rows[2];ti++){const t=info.row(2,ti);if(info.str(t[1])!=='THGame')continue;const fe=ti<info.rows[2]?info.row(2,ti+1)[4]:info.rows[4]+1,me=ti<info.rows[2]?info.row(2,ti+1)[5]:info.rows[6]+1,fields={};
   for(let fi=t[4];fi<fe;fi++)fields[info.str(info.row(4,fi)[1])]=0x04000000+fi;
   const remap=new Map([[fields.mFont6x6,fields.mUnicodeFont6x6],[fields.mFont8x8,fields.mUnicodeFont8x8]].filter(x=>x[0]&&x[1]));
   for(let mi=t[5];mi<me;mi++){const m=info.row(6,mi),name=info.str(m[3]);if(!['GetSmallFont','GetMediumFont','GetMediumMonoFont','GetUIFont','GetUISmallFont','GetConsoleFont','GetRandomizerSmallFont'].includes(name))continue;const bd=body(info,m[0]);if(!bd)continue;
    for(let p=bd.p;p<bd.p+bd.length-4;p++)if(b[p]===0x7b){const to=remap.get(dv.getUint32(p+1,true));if(to){dv.setUint32(p+1,to,true);changes.push('AV1: '+name+' → кириличний шрифт');p+=4;}}
   }
  }
 }
 return changes;
}
function replaceResource(input,name,replacement,game){
 const info=peInfo(input),parts=[],offsets=new Map();let length=0;
 for(const r of info.resources){const pad=align(length,8)-length;if(pad){parts.push(new Uint8Array(pad));length+=pad;}offsets.set(r.name,length);const data=r.name===name?bytes(replacement):r.data,header=new Uint8Array(4);new DataView(header.buffer).setUint32(0,data.length,true);parts.push(header,data);length+=4+data.length;}
 const resource=concat(parts),last=info.sections.reduce((a,b)=>b.raw+b.size>a.raw+a.size?b:a),fileAlign=info.v.getUint32(info.opt+36,true),sectionAlign=info.v.getUint32(info.opt+32,true);assert(fileAlign&&sectionAlign,'Невірне вирівнювання EXE.');
 const target=align(Math.max(info.b.length,last.raw+last.size),fileAlign),rawSize=align(target-last.raw+resource.length,fileAlign),out=new Uint8Array(last.raw+rawSize);out.set(info.b);out.set(resource,target);const v=new DataView(out.buffer);
 v.setUint32(last.p+16,rawSize,true);v.setUint32(last.p+8,Math.max(last.vs,target-last.raw+resource.length),true);v.setUint32(last.p+36,((v.getUint32(last.p+36,true)|0x40000040)&~0x02000000)>>>0,true);
 v.setUint32(info.opt+8,info.v.getUint32(info.opt+8,true)+rawSize-last.size,true);
 v.setUint32(info.opt+56,align(last.va+v.getUint32(last.p+8,true),sectionAlign),true);v.setUint32(info.cli+24,last.va+target-last.raw,true);v.setUint32(info.cli+28,resource.length,true);v.setUint32(info.opt+64,0,true);
 for(const r of info.resources)v.setUint32(r.tableOffset,offsets.get(r.name),true);
 // Binary edits cannot preserve an Authenticode certificate. Clear its directory.
 v.setUint32(info.dd+4*8,0,true);v.setUint32(info.dd+4*8+4,0,true);
 const changes=patchFontRouting(info,out,game),check=peInfo(out),rr=check.resources.find(x=>x.name===name);assert(rr&&rr.data.length===replacement.length,'Помилка складання EXE.');
 for(const r of info.resources)if(r.name!==name){const x=check.resources.find(x=>x.name===r.name);assert(x&&equal(x.data,r.data),'Змінився сторонній ресурс.');}
 return {bytes:out,changes};
}
function equal(a,b){return a.length===b.length&&a.every((x,i)=>x===b[i]);}
function parseCSV(s){s=s.replace(/^\uFEFF/,'');const rows=[];let row=[],value='',quote=false;for(let i=0;i<s.length;i++){const c=s[i];if(c==='"'){if(quote&&s[i+1]==='"'){value+='"';i++;}else if(quote||!value)quote=!quote;else value+=c;}else if(c===','&&!quote){row.push(value);value='';}else if((c==='\r'||c==='\n')&&!quote){if(c==='\r'&&s[i+1]==='\n')i++;row.push(value);rows.push(row);row=[];value='';}else value+=c;}assert(!quote,'Незакрита лапка в CSV.');if(value||row.length){row.push(value);rows.push(row);}return rows;}
const csvString=rows=>'\uFEFF'+rows.map(r=>r.map(x=>/[",\r\n]/.test(x)?'"'+x.replace(/"/g,'""')+'"':x).join(',')).join('\r\n')+'\r\n';
function parseXML(s){const doc=new DOMParser().parseFromString(s,'application/xml');assert(!doc.querySelector('parsererror'),'Пошкоджений XML.');return doc;}
function collectXML(doc,path){const entries=[],seen=new Map();let count=0;for(const el of doc.querySelectorAll('THTextEntry, THCutscenePage, THCreditsEntry, THCreditSection[mTitle]')){
 const attr=el.tagName==='THCreditSection'?'mTitle':null;const text=attr?el.getAttribute(attr):el.textContent;if(!text.trim())continue;
 const scene=el.closest('THCutsceneData')?.getAttribute('mName')||'',key=el.getAttribute('mKey')||[scene||el.tagName,String(++count).padStart(3,'0')].join('/');
 const occurrence=(seen.get(key)||0)+1;seen.set(key,occurrence);const unique=occurrence>1?key+'/'+occurrence:key;entries.push({id:path+'::'+unique,key:unique,original:text,translation:'',status:'draft',kind:'xml',node:el,attr,file:path,category:category(path),note:''});
 }return entries;}
function category(path){return path.split('/').pop().replace(/_English\.xml$|\.csv$/i,'');}
async function openGame(input,name){const b=bytes(input),info=peInfo(b),resource=info.resources.find(r=>/Content\.zip$/i.test(r.name));assert(resource,'У цій версії EXE немає вбудованого архіву Content.zip.');const zip=await JSZip.loadAsync(resource.data,{checkCRC32:true});
 const game=zip.file('Text/UI.csv')?2:zip.file('Text/UI_English.xml')?1:0;assert(game,'Не знайдено текстів Axiom Verge 1 або 2.');const entries=[],documents=new Map();
 for(const path of Object.keys(zip.files).sort()){if(game===2&&/^Text\/.+\.csv$/i.test(path)){const rows=parseCSV(await zip.file(path).async('string')),col=rows[0].indexOf('English');if(col<0)continue;documents.set(path,{kind:'csv',rows,col});for(let i=1;i<rows.length;i++){const r=rows[i];if(!r[0]||r.length<=col)continue;entries.push({id:path+'::'+r[0],key:r[0],original:r[col],translation:'',status:'draft',file:path,kind:'csv',row:i,category:category(path),note:''});}}
 else if(/^Text\/.+_English\.xml$/i.test(path)&&(game===1||/Credits_English/.test(path))){const doc=parseXML(await zip.file(path).async('string'));documents.set(path,{kind:'xml',doc});entries.push(...collectXML(doc,path));}}
 const hash=await sha256(b);return {name:name||`AxiomVerge${game===2?'2':''}.exe`,game,bytes:b,zip,resourceName:resource.name,documents,entries,hash,fonts:[],changes:[]};}
function normalize(text){return text.replace(/\\r\\n|\\n|\\r/g,'\n').replace(/\r\n?/g,'\n');}
function validateEntry(e){const value=e.translation,issues=[];if(!value)return issues;if(/\\[nr]/.test(value))issues.push({type:'error',message:'Буквальний \\n: натисніть «Виправити переноси».'});
 const token=t=>t.match(/<[^>]+>|\{\d+[^}]*\}|%[dsf]/g)||[];const original=token(e.original),translated=token(value);for(const x of new Set(original))if(original.filter(t=>t===x).length!==translated.filter(t=>t===x).length)issues.push({type:'error',message:'Не збігається службовий код '+x});
 if(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))issues.push({type:'error',message:'Недопустимі керівні символи.'});if(value.length>Math.max(36,e.original.length*1.7))issues.push({type:'warning',message:'Текст суттєво довший за оригінал: перевірте у грі.'});return issues;}
async function sha256(b){if(global.crypto?.subtle)return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b))).map(x=>x.toString(16).padStart(2,'0')).join('');return null;}
function projectData(game){return {format:'verge-uk-project',version:1,game:game.game,filename:game.name,sourceHash:game.hash,updatedAt:new Date().toISOString(),entries:game.entries.map(({id,key,file,original,translation,status,note})=>({id,key,file,original,translation,status,note}))};}
function applyProject(game,data){assert(data.format==='verge-uk-project'&&data.version===1&&Array.isArray(data.entries),'Непідтримуваний файл проєкту.');assert(data.game===game.game,'Проєкт належить іншій частині гри.');const byID=new Map(game.entries.map(e=>[e.id,e]));let applied=0,skipped=0;for(const r of data.entries){const e=byID.get(r.id);if(!e||e.original!==r.original){skipped++;continue;}assert(typeof r.translation==='string','Некоректний переклад.');e.translation=r.translation;e.status=['draft','translated','reviewed'].includes(r.status)?r.status:'draft';e.note=typeof r.note==='string'?r.note:'';applied++;}return {applied,skipped,differentHash:data.sourceHash&&game.hash&&data.sourceHash!==game.hash};}
async function buildPatch(game,{allowIncomplete=true,patchFonts=true}={}){
 const errors=game.entries.flatMap(e=>validateEntry(e).filter(i=>i.type==='error').map(i=>({key:e.key,...i})));assert(!errors.length,'Спершу виправте помилки: '+errors[0]?.key+' — '+errors[0]?.message);
 assert(allowIncomplete||game.entries.every(e=>e.translation),'Не всі тексти перекладено.');const modified=new Map();
 for(const [path,d] of game.documents){if(d.kind==='csv'){const rows=d.rows.map(r=>r.slice());let changed=false;for(const e of game.entries.filter(e=>e.file===path))if(e.translation){rows[e.row][d.col]=normalize(e.translation);changed=true;}if(changed)modified.set(path,enc.encode(csvString(rows)));}
 else{const cloned=d.doc.cloneNode(true),oldEntries=collectXML(cloned,path);let changed=false;for(const e of game.entries.filter(e=>e.file===path)){const n=oldEntries.find(x=>x.id===e.id);if(e.translation&&n){if(n.attr)n.node.setAttribute(n.attr,normalize(e.translation));else n.node.textContent=normalize(e.translation);changed=true;}}if(changed){const s=new XMLSerializer().serializeToString(cloned);parseXML(s);modified.set(path,enc.encode(s));}}}
 assert(modified.size,'Додайте хоча б один переклад перед створенням патча.');const zip=await JSZip.loadAsync(game.resourceName?peInfo(game.bytes).resources.find(x=>x.name===game.resourceName).data:game.zip);
 for(const [path,b] of modified)zip.file(path,b,{createFolders:false});const archive=await zip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:9}}),check=await JSZip.loadAsync(archive,{checkCRC32:true});assert(Object.keys(check.files).length===Object.keys(game.zip.files).length,'Змінилася структура архіву.');
 const patched=replaceResource(game.bytes,game.resourceName,archive,game.game),out=new JSZip();out.file(game.name,patched.bytes);const fontReport=[];
 if(patchFonts){assert(game.fonts.length,'Додайте шрифти: виберіть папку гри або папку Content.');for(const f of game.fonts){try{const result=patchXNB(f.bytes,f.path);if(result){out.file(f.path,result.bytes);fontReport.push({path:f.path,added:result.added});}}catch(error){fontReport.push({path:f.path,error:error.message});}}
  const required=game.game===1?['LucidaConsole6XNA.xnb','LucidaConsole8XNA.xnb','Moire16XNA.xnb']:['AV8ptMonogame.xnb','Hooge0655_8pt.xnb','Moire16pt.xnb','Uni0553_6pt.xnb','Uni0553_8pt.xnb'];for(const name of required)assert(fontReport.some(f=>f.path.endsWith('/'+name)&&!f.error),'Додайте сумісний шрифт '+name+' з папки Content гри.');
 }
 if(game.game===1)assert(patched.changes.length,'Ця версія AV1 має іншу систему шрифтів. Експортуйте тексти й зверніться по адаптацію EXE.');
 const report={game:game.game,sourceHash:game.hash,patchedHash:await sha256(patched.bytes),entriesTranslated:game.entries.filter(e=>e.translation).length,entriesTotal:game.entries.length,changedFiles:[...modified.keys()],fonts:fontReport,binaryChanges:patched.changes,createdAt:new Date().toISOString()};
 out.file('UA-patch-report.json',JSON.stringify(report,null,2));out.file('UA-README.txt',`Український патч для Axiom Verge ${game.game}\n\nЗакрийте гру. Збережіть резервну копію EXE та папки Content.\nРозпакуйте цей архів у папку гри з об'єднанням папок і заміною файлів.\nОберіть English у грі: ця позиція міститиме ваш переклад.\nНеперекладені записи залишаються як в оригіналі.\nПерекладено ${report.entriesTranslated} із ${report.entriesTotal} записів.\n\nПісля оновлення гри створіть патч заново з нового EXE.\nПеревірте переноси й розташування тексту у грі: вебперегляд є орієнтовним.\n`);
 return {bytes:await out.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}}),report};
}
class Reader{constructor(b){this.b=bytes(b);this.v=new DataView(this.b.buffer,this.b.byteOffset,this.b.byteLength);this.p=10;}n(kind){const fn={i:'getInt32',u:'getUint32',f:'getFloat32',byte:'getUint8'}[kind],w=kind==='byte'?1:4;assert(this.p+w<=this.b.length,'Шрифт обірваний.');const n=this.v[fn](this.p,true);this.p+=w;return n;}vi(){let n=0,s=0;for(let i=0;i<5;i++){const c=this.n('byte');n+=(c&127)*2**s;s+=7;if(c<128)return n;}throw new Error('Некоректний індекс XNB.');}str(){const n=this.vi(),s=utf8.decode(this.b.subarray(this.p,this.p+n));this.p+=n;return s;}char(){const c=this.b[this.p],n=c<128?1:c<224?2:c<240?3:4,s=utf8.decode(this.b.subarray(this.p,this.p+n));this.p+=n;return s;}}
function parseXNB(input){const r=new Reader(input);assert(String.fromCharCode(...r.b.slice(0,3))==='XNB','Це не XNB.');assert(!(r.b[5]&0xc0),'Стиснений XNB: потрібна окрема адаптація.');assert(r.v.getUint32(6,true)===r.b.length,'Невірна довжина XNB.');const readers=[];for(let i=r.vi();i>0;i--)readers.push([r.str(),r.n('i')]);const shared=r.vi(),root=r.vi();if(!readers[root-1]?.[0].includes('SpriteFontReader'))return null;assert(shared===0,'Шрифт зі спільними ресурсами не підтримується.');const texreader=r.vi(),format=r.n('i'),width=r.n('i'),height=r.n('i'),levels=r.n('i');assert(format===0&&levels===1,'Потрібна RGBA-текстура шрифту без mip-рівнів.');const len=r.n('i');assert(len===width*height*4&&width>0&&width<=8192&&height>0&&height<=8192,'Некоректна текстура шрифту.');const pixels=r.b.slice(r.p,r.p+len);r.p+=len;const types=[],arrays=[];
 for(let j=0;j<3;j++){types.push(r.vi());const n=r.n('i');assert(n>=0&&n<100000,'Некоректна таблиця символів.');const a=[];for(let i=0;i<n;i++)a.push(j===2?r.char():[r.n('i'),r.n('i'),r.n('i'),r.n('i')]);arrays.push(a);}
 const line=r.n('i'),spacing=r.n('f'),kernType=r.vi(),n=r.n('i'),kern=[];for(let i=0;i<n;i++)kern.push([r.n('f'),r.n('f'),r.n('f')]);const has=r.n('byte'),def=has?r.char():null;assert(r.p===r.b.length&&arrays.every(a=>a.length===n),'Несумісна структура SpriteFont.');return {header:r.b.slice(0,6),readers,root,texreader,width,height,pixels,types,arrays,line,spacing,kernType,kern,def};
}
class Writer{constructor(){this.parts=[];}n(kind,x){const b=new Uint8Array(kind==='byte'?1:4),v=new DataView(b.buffer);v[{i:'setInt32',u:'setUint32',f:'setFloat32',byte:'setUint8'}[kind]](0,x,true);this.parts.push(b);}vi(n){const a=[];while(n>=128){a.push(n%128|128);n=Math.floor(n/128);}a.push(n);this.parts.push(new Uint8Array(a));}str(s){const b=enc.encode(s);this.vi(b.length);this.parts.push(b);}finish(){return concat(this.parts);}}
function serializeXNB(f,pixels,height,entries){const w=new Writer();w.vi(f.readers.length);for(const [s,n] of f.readers){w.str(s);w.n('i',n);}w.vi(0);w.vi(f.root);w.vi(f.texreader);for(const n of [0,f.width,height,1,pixels.length])w.n('i',n);w.parts.push(pixels);const keys=[...entries.keys()].sort((a,b)=>a.codePointAt(0)-b.codePointAt(0));
 for(let j=0;j<3;j++){w.vi(f.types[j]);w.n('i',keys.length);for(const c of keys){if(j===2)w.parts.push(enc.encode(c));else for(const n of entries.get(c)[j])w.n('i',n);}}
 w.n('i',f.line);w.n('f',f.spacing);w.vi(f.kernType);w.n('i',keys.length);for(const c of keys)for(const n of entries.get(c)[2])w.n('f',n);w.n('byte',f.def?1:0);if(f.def)w.parts.push(enc.encode(f.def));const body=w.finish(),head=new Uint8Array(10);head.set(f.header);new DataView(head.buffer).setUint32(6,body.length+10,true);return concat([head,body]);}
const UK='АБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯабвгґдеєжзиіїйклмнопрстуфхцчшщьюя';
function patchXNB(input,path){const f=parseXNB(input);if(!f)return null;const entries=new Map(f.arrays[2].map((c,i)=>[c,[f.arrays[0][i],f.arrays[1][i],f.kern[i]]]));const glyphs=[];
 function original(c){const [rect,crop,kern]=entries.get(c),[x,y,w,h]=rect,pixels=new Uint8Array(w*h*4);for(let row=0;row<h;row++)pixels.set(f.pixels.subarray(((y+row)*f.width+x)*4,((y+row)*f.width+x+w)*4),row*w*4);return {w,h,pixels,crop:crop.slice(),kern:kern.slice()};}
 const main=/AV8ptMonogame\.xnb$/i.test(path);
 for(const c of [...UK,...'—–…’']){if(entries.has(c)&&!main)continue;let g;
  const source={Ґ:'Г',ґ:'г',Є:'Э',є:'э',І:'I',і:'i',Ї:'I',ї:'i','’':"'",'—':'-','–':'-','…':'.'}[c];
  if(source&&entries.has(source)&&!main){g=original(source);if(c==='Є'||c==='є'){const px=new Uint8Array(g.pixels.length);for(let y=0;y<g.h;y++)for(let x=0;x<g.w;x++)px.set(g.pixels.subarray((y*g.w+x)*4,(y*g.w+x+1)*4),(y*g.w+g.w-1-x)*4);g.pixels=px;}
   if('ҐґЇї'.includes(c)){const old=g,extra='Ґґ'.includes(c)?Math.max(1,Math.floor(old.h/8)):Math.max(2,Math.floor(old.h/5)),w='Її'.includes(c)?Math.max(5,old.w):old.w,h=old.h+extra,px=new Uint8Array(w*h*4),inset=Math.floor((w-old.w)/2);for(let y=0;y<old.h;y++)px.set(old.pixels.subarray(y*old.w*4,(y+1)*old.w*4),((y+extra)*w+inset)*4);const dot=(x,y)=>px.fill(255,(y*w+x)*4,(y*w+x+1)*4);if('Ґґ'.includes(c))for(let y=0;y<=extra;y++)for(let x=w-extra;x<w;x++)dot(x,y);else for(let y=0;y<Math.max(1,Math.floor(old.h/9));y++){dot(0,y);dot(w-1,y);}g={w,h,pixels:px,crop:[old.crop[0],old.crop[1]-extra,'Її'.includes(c)?w+2:old.crop[2],old.crop[3]],kern:'Її'.includes(c)?[0,w+2,0]:old.kern};}
  }else{const rows=global.UA_GLYPHS[c];if(!rows)continue;const scale=main?1:Math.max(1,Math.floor((entries.has('A')?entries.get('A')[0][3]:f.line)/7)),w=5*scale,h=7*scale,px=new Uint8Array(w*h*4);for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(rows[Math.floor(y/scale)]&(1<<(4-Math.floor(x/scale))))px.fill(255,(y*w+x)*4,(y*w+x+1)*4);g={w,h,pixels:px,crop:[0,Math.max(0,Math.floor((f.line-h)/2)),w+scale,f.line],kern:[0,w+scale,0]};}
  glyphs.push([c,g]);
 }
 const rowHeight=Math.max(1,...glyphs.map(([,g])=>g.h))+2,height=f.height+rowHeight*(2+Math.floor(glyphs.reduce((n,[,g])=>n+g.w+2,0)/f.width)),pixels=new Uint8Array(f.width*height*4);pixels.set(f.pixels);let x=1,y=f.height+1;
 for(const [c,g] of glyphs){if(x+g.w+1>f.width){x=1;y+=rowHeight;}assert(y+g.h<=height,'Не вистачило місця в атласі.');for(let r=0;r<g.h;r++)pixels.set(g.pixels.subarray(r*g.w*4,(r+1)*g.w*4),((y+r)*f.width+x)*4);entries.set(c,[[x,y,g.w,g.h],g.crop,g.kern]);x+=g.w+2;}
 const result=serializeXNB(f,pixels,height,entries),parsed=parseXNB(result);assert([...UK].every(c=>parsed.arrays[2].includes(c)),'Не всі українські літери додано.');return {bytes:result,added:glyphs.length,font:parsed};
}
function fontPath(file,game){const raw=(file.webkitRelativePath||file.name).replace(/\\/g,'/'),i=raw.indexOf('Content/');if(i>=0)return raw.slice(i);const name=raw.split('/').pop();return game===1?/^(CJKFont|TestFont|Hud)/.test(name)?'Content/Fonts/'+name:'Content/Art/Textures/UI/Fonts/'+name:'Content/Fonts/'+name;}
const api={peInfo,replaceResource,parseCSV,csvString,parseXML,collectXML,openGame,normalize,validateEntry,projectData,applyProject,buildPatch,parseXNB,patchXNB,fontPath,sha256,UK,equal};global.Verge=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
