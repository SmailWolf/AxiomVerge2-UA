from pathlib import Path
import struct
class Reader:
 def __init__(self,b):self.b=b;self.p=10
 def n(self,fmt):
  v=struct.unpack_from('<'+fmt,self.b,self.p);self.p+=struct.calcsize('<'+fmt);return v[0] if len(v)==1 else v
 def vi(self):
  n=0;s=0
  while True:
   c=self.n('B');n|=(c&127)<<s;s+=7
   if c<128:return n
 def st(self):
  n=self.vi();s=self.b[self.p:self.p+n].decode();self.p+=n;return s
 def ch(self):
  for n in range(1,5):
   try:s=self.b[self.p:self.p+n].decode('utf-8');self.p+=n;return s
   except UnicodeDecodeError:pass
 def obj(self):return self.vi()
def load(p):
 r=Reader(Path(p).read_bytes());readers=[(r.st(),r.n('i')) for _ in range(r.vi())];shared=r.vi();root=r.obj();texreader=r.obj();fmt,w,h,levels=r.n('4i');textures=[]
 for _ in range(levels):
  n=r.n('i');textures.append(r.b[r.p:r.p+n]);r.p+=n
 arrays=[]
 for form in ['4i','4i','char']:
  typ=r.obj();n=r.n('i');a=[r.ch() if form=='char' else r.n(form) for _ in range(n)];arrays.append((typ,a))
 line,spacing=r.n('if');typ=r.obj();n=r.n('i');kern=[r.n('3f') for _ in range(n)];has=r.n('?');default=r.ch() if has else None
 assert r.p==len(r.b),(r.p,len(r.b))
 return locals()
if __name__=='__main__':
 for p in Path('/mnt/SHHD/SteamLibrary/steamapps/common/Axiom Verge 2/Content/Fonts').glob('*.xnb'):
  try:
   f=load(p);chars=f['arrays'][2][1];print(p.name,f['fmt'],f['w'],f['h'],len(chars),'line',f['line'],'missing', ''.join(c for c in 'АБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯабвгґдеєжзиіїйклмнопрстуфхцчшщьюя’' if c not in chars))
  except Exception as e:print(p.name,e)
