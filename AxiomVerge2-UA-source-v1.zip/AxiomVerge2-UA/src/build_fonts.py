from pathlib import Path
from font import load
from PIL import Image,ImageDraw,ImageOps
import struct,json,sys
SOURCE=Path(sys.argv[1]).resolve()
OUT=Path(sys.argv[2]).resolve();OUT.mkdir(parents=True,exist_ok=True)
REPORT=Path(sys.argv[3]).resolve()
UK='АБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯабвгґдеєжзиіїйклмнопрстуфхцчшщьюя'
# Each glyph is a 5 by 7 pixel grid, with one pixel of horizontal spacing.
patterns={
'А':[14,17,17,31,17,17,17],'Б':[31,16,16,30,17,17,30],'В':[30,17,17,30,17,17,30],
'Г':[31,16,16,16,16,16,16],'Ґ':[1,31,16,16,16,16,16],'Д':[6,10,10,10,10,31,17],
'Е':[31,16,16,30,16,16,31],'Є':[14,17,16,28,16,17,14],'Ж':[21,21,21,14,21,21,21],
'З':[14,17,1,6,1,17,14],'И':[17,17,19,21,25,17,17],'І':[14,4,4,4,4,4,14],
'Ї':[10,0,14,4,4,4,14],'Й':[10,4,17,19,21,25,17],'К':[17,18,20,24,20,18,17],
'Л':[7,9,9,9,9,9,17],'М':[17,27,21,21,17,17,17],'Н':[17,17,17,31,17,17,17],
'О':[14,17,17,17,17,17,14],'П':[31,17,17,17,17,17,17],'Р':[30,17,17,30,16,16,16],
'С':[14,17,16,16,16,17,14],'Т':[31,4,4,4,4,4,4],'У':[17,17,17,15,1,17,14],
'Ф':[4,14,21,21,21,14,4],'Х':[17,17,10,4,10,17,17],'Ц':[18,18,18,18,18,31,1],
'Ч':[17,17,17,15,1,1,1],'Ш':[21,21,21,21,21,21,31],'Щ':[21,21,21,21,21,31,1],
'Ь':[16,16,16,30,17,17,30],'Ю':[18,21,21,29,21,21,18],'Я':[15,17,17,15,5,9,17],
'а':[0,0,14,1,15,17,15],'б':[3,12,16,30,17,17,14],'в':[0,0,30,17,30,17,30],
'г':[0,0,31,16,16,16,16],'ґ':[0,1,31,16,16,16,16],'д':[0,0,6,10,10,31,17],
'е':[0,0,14,17,31,16,14],'є':[0,0,14,17,28,17,14],'ж':[0,0,21,21,14,21,21],
'з':[0,0,14,17,6,17,14],'и':[0,0,17,19,21,25,17],'і':[4,0,4,4,4,4,4],
'ї':[10,0,4,4,4,4,4],'й':[10,4,17,19,21,25,17],'к':[0,0,17,18,28,18,17],
'л':[0,0,7,9,9,9,17],'м':[0,0,17,27,21,17,17],'н':[0,0,17,17,31,17,17],
'о':[0,0,14,17,17,17,14],'п':[0,0,31,17,17,17,17],'р':[0,0,30,17,30,16,16],
'с':[0,0,14,17,16,17,14],'т':[0,0,31,4,4,4,4],'у':[0,0,17,17,15,1,14],
'ф':[4,4,14,21,21,14,4],'х':[0,0,17,10,4,10,17],'ц':[0,0,18,18,18,31,1],
'ч':[0,0,17,17,15,1,1],'ш':[0,0,21,21,21,21,31],'щ':[0,0,21,21,21,31,1],
'ь':[0,0,16,16,30,17,30],'ю':[0,0,18,21,29,21,18],'я':[0,0,15,17,15,5,17],
'ы':[0,0,17,17,25,21,25],'э':[0,0,14,17,7,17,14],'ъ':[0,0,24,8,14,9,14],
'—':[0,0,0,31,0,0,0],'–':[0,0,0,14,0,0,0],'…':[0,0,0,0,0,0,21],'’':[4,4,8,0,0,0,0]
}
def vi(n):
 b=bytearray()
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return bytes(b)
def st(s):b=s.encode();return vi(len(b))+b
def pack(fmt,*v):return struct.pack('<'+fmt,*v)
def save(f,tex,entries,path):
 b=vi(len(f['readers']))
 for s,v in f['readers']:b+=st(s)+pack('i',v)
 b+=vi(0)+vi(f['root'])+vi(f['texreader'])+pack('4i',0,tex.width,tex.height,1)
 pixels=tex.tobytes();b+=pack('i',len(pixels))+pixels
 keys=sorted(entries)
 for j,form in [(0,'4i'),(1,'4i'),(2,'char')]:
  b+=vi(f['arrays'][j][0])+pack('i',len(keys))
  for c in keys:b+=c.encode('utf-8') if j==2 else pack(form,*entries[c][j])
 b+=pack('if',f['line'],f['spacing'])+vi(f['typ'])+pack('i',len(keys))
 for c in keys:b+=pack('3f',*entries[c][2])
 b+=pack('?',f['has'])+(f['default'].encode() if f['has'] else b'')
 path.write_bytes(f['r'].b[:6]+pack('i',10+len(b))+b)
def grid(rows):
 im=Image.new('RGBA',(5,7))
 for y,n in enumerate(rows):
  for x in range(5):
   if n&(1<<(4-x)):im.putpixel((x,y),(255,255,255,255))
 return im
report=[]
for src in SOURCE.glob('*.xnb'):
 try:f=load(src)
 except Exception:continue
 original=Image.frombytes('RGBA',(f['w'],f['h']),f['textures'][0]);entries={c:(f['arrays'][0][1][i],f['arrays'][1][1][i],f['kern'][i]) for i,c in enumerate(f['arrays'][2][1])}
 def glyph(c):
  rec,cr,k=entries[c];x,y,w,h=rec;return original.crop((x,y,x+w,y+h)),cr,k
 added={}
 if src.stem=='AV8ptMonogame':
  for c,rows in patterns.items():added[c]=(grid(rows),(0,0,6,8),(0.,6.,0.))
 else:
  for c,base in [('Ґ','Г'),('ґ','г'),('Є','Э'),('є','э'),('І','I'),('і','i'),('Ї','I'),('ї','i')]:
   g,cr,k=glyph(base);g=g.copy();cr=list(cr);k=list(k)
   if c in 'Єє':g=ImageOps.mirror(g)
   if c in 'Ґґ':
    extra=max(1,g.height//8);v=Image.new('RGBA',(g.width,g.height+extra));v.alpha_composite(g,(0,extra));ImageDraw.Draw(v).rectangle((g.width-extra,0,g.width-1,extra),fill='white');g=v;cr[1]-=extra
   if c=='Ї':
    extra=max(2,g.height//5);wide=max(5,g.width);v=Image.new('RGBA',(wide,g.height+extra));v.alpha_composite(g,((wide-g.width)//2,extra));d=ImageDraw.Draw(v);dot=max(1,round(g.height/7));d.rectangle((0,0,dot-1,dot-1),fill='white');d.rectangle((wide-dot,0,wide-1,dot-1),fill='white');g=v;cr[1]-=extra;cr[2]=wide+2;k=[0.,wide+2.,0.]
   if c=='ї':
    # Replace the Latin i's single dot with the two Ukrainian dieresis dots.
    # Keeping the stem and baseline in place avoids the old three-dot glyph.
    wide=max(5,g.width);stem=g.copy();d=ImageDraw.Draw(stem);d.rectangle((0,0,stem.width-1,min(stem.height-1,max(1,stem.height//5))),fill=(255,255,255,0));v=Image.new('RGBA',(wide,g.height));v.alpha_composite(stem,((wide-g.width)//2,0));d=ImageDraw.Draw(v);dot=max(1,round(g.height/7));d.rectangle((0,0,dot-1,dot-1),fill='white');d.rectangle((wide-dot,0,wide-1,dot-1),fill='white');g=v;cr[2]=wide+2;k=[0.,wide+2.,0.]
   added[c]=(g,tuple(cr),tuple(k))
  if src.stem=='Moire16pt':
   # The original Moire capital I is only a bare 2px column. Give Ukrainian
   # І/Ї the same balanced top and bottom serifs as the game's other capitals.
   def bitmap(rows,w):
    im=Image.new('RGBA',(w,len(rows)))
    for yy,row in enumerate(rows):
     for xx in range(w):
      if row&(1<<(w-1-xx)):im.putpixel((xx,yy),(255,255,255,255))
    return im
   upper_i=bitmap([1023,1023]+[48]*11+[1023,1023],10)
   upper_yi=bitmap([0b0110000110,0b0110000110,0,1023,1023]+[48]*11+[1023,1023],10)
   lower_yi=bitmap([0b11000011,0b11000011,0,0]+[24]*11,8)
   added['І']=(upper_i,(1,5,12,29),(0.,12.,0.))
   added['Ї']=(upper_yi,(1,2,12,29),(0.,12.,0.))
   added['ї']=(lower_yi,(1,5,10,29),(0.,10.,0.))
  for c,base in [('’',"'"),('—','-'),('–','-'),('…','.')]:
   if c not in entries:added[c]=glyph(base)
 rowheight=max(g.height for g,_,_ in added.values())+2
 tex=Image.new('RGBA',(original.width,original.height+rowheight*(2+sum(g.width+2 for g,_,_ in added.values())//original.width)));tex.alpha_composite(original);x=1;y=original.height+1
 for c,(g,cr,k) in added.items():
  if x+g.width+1>tex.width:x=1;y+=rowheight
  assert y+g.height<=tex.height
  tex.alpha_composite(g,(x,y));entries[c]=((x,y,g.width,g.height),cr,k);x+=g.width+2
 save(f,tex,entries,OUT/src.name)
 parsed=load(OUT/src.name);assert set(UK)<=set(parsed['arrays'][2][1]);report.append({'font':src.name,'patched_glyphs':len(added),'characters':len(entries)})
REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
