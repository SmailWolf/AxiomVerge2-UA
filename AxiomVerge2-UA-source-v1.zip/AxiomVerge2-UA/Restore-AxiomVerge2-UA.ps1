$ErrorActionPreference = 'Stop'
try {
    if (!(Get-Command py.exe -ErrorAction SilentlyContinue)) { throw 'Не знайдено Python launcher py.' }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Виберіть папку Axiom Verge 2 з установленим українізатором'
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 1 }
    & py.exe -3 (Join-Path $PSScriptRoot 'install.py') $dialog.SelectedPath --restore
    if ($LASTEXITCODE -ne 0) { throw 'Відновлення не завершено.' }
    Read-Host 'Готово. Натисніть Enter, щоб закрити'
} catch {
    Write-Host "Помилка: $($_.Exception.Message)" -ForegroundColor Red
    Read-Host 'Натисніть Enter, щоб закрити'
    exit 1
}
